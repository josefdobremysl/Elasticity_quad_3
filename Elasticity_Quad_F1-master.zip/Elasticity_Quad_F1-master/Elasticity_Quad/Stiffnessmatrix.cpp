﻿#include "mesh_processor.h"

#include "function.h"
#include "Assemblematrix.h"

#include <Eigen/Sparse>
#include <armadillo>
#include <omp.h>


#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <tuple>
#include <numeric>
#include <chrono>	
using namespace Eigen;
using namespace std;
using namespace arma;



SparseMatrixVectorResult StiffnessMatrix(const string& meshFile) {


	double E = 1000;					// Materiálové vlastnosti
	double sigma = 0.3;
	double lambda = E * sigma / ((1 + sigma) * (1 - 2 * sigma));
	double mu = E / (2 * (1 + sigma));



	MatrixVectorResult result = GetTriangles(meshFile);


	int nTri = result.integerResult;		// poèet trojúhelníkù
	int nNodes = result.matrix3.size();			// poèet bodù
	//cout << "nNodes  " << nNodes << endl;
	int nNodes2 = 2 * nNodes;
	int nNodesIJ = nNodes2 * 12*12*4;
	//cout << "nTri" << nTri << endl;
	
	vector<int> I(nNodesIJ, 0);
	vector<int> J(nNodesIJ, 0);
	vector<double> VAL(nNodesIJ, 0);
	vector<double> right_side_vector(nNodes2, 0);		// vektor pravé strany
	//cout << nNodes2 << endl;


	// Vytvoøení matice basisFE_ref
	mat basisFE_ref = { // bazove f-ce v x-smeru a pak baz. fce v y-smeru
		{0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{0.0,  0.0,  0.0,  1.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{0.0,  0.0,  0.0,  0.0,  1.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{0.0,  0.0,  0.0,  0.0,  0.0,  1.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  1.0,  0.0,  0.0},
		{0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  1.0,  0.0},
		{0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  1.0}
	};
	// PD podle X baz. fci v kvadr. uzlech
	mat gradFEx_ref = {
		{-1.0,  1.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{ 1.0,  1.0,  0.0, -2.0,  2.0, -2.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{-1.0, -1.0,  0.0,  2.0,  2.0, -2.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{ 0.0,  0.0,  0.0,  0.0,  0.0,  0.0, -1.0,  1.0,  0.0,  0.0,  0.0,  0.0},
		{ 0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  1.0,  1.0,  0.0, -2.0,  2.0, -2.0},
		{ 0.0,  0.0,  0.0,  0.0,  0.0,  0.0, -1.0, -1.0,  0.0,  2.0,  2.0, -2.0}
	};
	// PD podle Y baz. fci v kvadr. uzlech
	mat gradFEy_ref = {
		{-1.0,  0.0, -1.0, -2.0,  2.0,  2.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{ 1.0,  0.0,  1.0, -2.0,  2.0, -2.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{-1.0,  0.0,  1.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0},
		{ 0.0,  0.0,  0.0,  0.0,  0.0,  0.0, -1.0,  0.0, -1.0, -2.0,  2.0,  2.0},
		{ 0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  1.0,  0.0,  1.0, -2.0,  2.0, -2.0},
		{ 0.0,  0.0,  0.0,  0.0,  0.0,  0.0, -1.0,  0.0,  1.0,  0.0,  0.0,  0.0}
	};

	double nQuadrature = 3;
	double w = 1 / nQuadrature;
	int index_IJ = 0;


	for (int k = 0; k < nTri; k++) {
		int A = result.matrix1[k][0] - 1;					// Oznaèení vrcholù trojúhelníku k
		int B = result.matrix1[k][1] - 1;
		int C = result.matrix1[k][2] - 1;
		int D = result.matrix1[k][3] - 1;					// Oznaèení stredu stran trojúhelníku k
		int E = result.matrix1[k][4] - 1;
		int F = result.matrix1[k][5] - 1;

		vector<int> verTri = { A, B, C, D, E, F };

		vector<double> cooA = result.matrix3[A];		// Souøadnice vrcholù trojúhelníku k
		vector<double> cooB = result.matrix3[B];
		vector<double> cooC = result.matrix3[C];

		mat CoQ = {
			{ cooA[0],cooB[0],cooC[0],(cooA[0] + cooB[0]) / 2, (cooB[0] + cooC[0]) / 2, (cooC[0] + cooA[0]) / 2},
			{ cooA[1],cooB[1],cooC[1],(cooA[1] + cooB[1]) / 2, (cooB[1] + cooC[1]) / 2, (cooC[1] + cooA[1]) / 2},
		};

		mat matA = {
			{ cooB[0] - cooA[0], cooC[0] - cooA[0] },
			{ cooB[1] - cooA[1], cooC[1] - cooA[1] },
		};

		double detA = matA(0, 0) * matA(1, 1) - matA(0, 1) * matA(1, 0);

		mat invA = {
			{  matA(1,1) / detA, -matA(0,1) / detA },
			{ -matA(1,0) / detA,  matA(0,0) / detA  },
		};

		mat gradFEx = invA(0, 0) * gradFEx_ref + invA(1, 0) * gradFEy_ref;
		mat gradFEy = invA(0, 1) * gradFEx_ref + invA(1, 1) * gradFEy_ref;

		vector<int> index = { A, B, C, D, E, F, nNodes + A, nNodes + B, nNodes + C, nNodes + D, nNodes + E, nNodes + F };

		for (int i = 0; i < 12; ++i) {
			for (int j = 0; j < 12; ++j) {
				double k_val = 0;
				for (int l = 0; l < nQuadrature; ++l) {
					vector<double> ee_i = { gradFEx(l,i), gradFEy( nQuadrature + l,i), gradFEx( nQuadrature + l,i) + gradFEy(l,i) };
					//vector<double> gradFI_i = { gradFEx(l,i), gradFEy( l,i), gradFEx(l + nQuadrature,i), gradFEy(nQuadrature + l,i) };
					double div_i = gradFEx( l,i) + gradFEy( nQuadrature + l,i);
					vector<double> sigma_i = { lambda * div_i + 2 * mu * ee_i[0], lambda * div_i + 2 * mu * ee_i[1], 2 * mu * ee_i[2]};
					vector<double> ee_j = { gradFEx(l,j), gradFEy( nQuadrature + l,j), gradFEx( nQuadrature + l,j) + gradFEy(l,j) };
					//vector<double> gradFI_j = { gradFEx(l,j), gradFEy(l,j), gradFEx(l + nQuadrature,j), gradFEy( nQuadrature + l,j)};

					k_val = k_val + detA / 2 * w * dotprod(sigma_i, ee_j);
					//k_val = k_val + detA / 2 * w * dotprod(gradFI_i, gradFI_j);
						//(gradFEx(l, j) * gradFEx(l, i) + gradFEy(l, i) * gradFEy(l, j));
					//cout << "kval" << k_val << endl;
					//cout << sigma_i << endl;


				};

		//for (int i = 0; i < 3; ++i) {
		//	for (int j = 0; j < 3; ++j) {
		//		double k_val = 0;
		//		for (int l = 0; l < nQuadrature; ++l) {
		//					/*cout << "detA" << detA;*/
		//			k_val = k_val + 0.5 * detA * w * (gradFEx(l,j) * gradFEx(l,i) + gradFEy(l,i) * gradFEy(l,j));
		//					/*cout <<"i,j,l"<<i<<" " << j << " " << l << " "<< "k_val" << k_val << "detA" << detA << "w" << w << "gradFEx[i][l]" << gradFEx[i][l] << "gradFEx[j][l]" << gradFEx[j][l] << "gradFEy[i][l]" << gradFEy[i][l] << "gradFEy[j][l]" << gradFEy[j][l]<<endl;*/
		//		};
				// zapis vysledneho soucinu vektoru-tenzoru na spravne misto do tripletu 
				I[index_IJ] = index[i];
				//cout << "index[i]" << index[i]<<endl;
				J[index_IJ] = index[j];
				/*cout << "index[j]" << index[j] << endl;*/
				VAL[index_IJ] = k_val;
				index_IJ++;
			}
			vector<double> fV(12, 0);
			for (int m = 0; m < 6; ++m) {
				double X = CoQ(0, m);
				double Y = CoQ(1, m);
				//double fx = 3 * X;	// Function(X, Y);
				//double fy = 2 * Y;
				fV[m] = FunctionV(X, Y)[0];
				fV[m + 6] = FunctionV(X, Y)[1];
			}
			//cout << "fV" << endl;
			//for (int i = 0; i < 12; ++i) {
			//	cout << fV[i] << endl;

			//}
			vector<double> basisFE_ref_i = arma::conv_to<std::vector<double>>::from(basisFE_ref.row(i));
			right_side_vector[index[i]] = 0.5 * detA * w * dotprod( fV, basisFE_ref_i);

			/*if (index[i] < (right_side_vector.size())) {
			}*/

			//int rr[] = {3,4,5,9,10,11};
			//vector<double> basisFE_ref_i(6,0);
			//for (int r=0; r < 6; ++r) {
			//	basisFE_ref_i[r] = basisFE_ref(r, i);
			//}
			//cout << "index[i]  " << index[i] << endl;


		};
	};

	SparseMatrixVectorResult assembledMatrix = AssembledMatrix(I, J, VAL, right_side_vector);
	SparseMatrix<double> K = assembledMatrix.sparsematrix;
	//std::cout << K << endl;

	return assembledMatrix;
}