﻿#include "mesh_processor.h"
#include "Dirichlet.h"
#include "Neumann.h"
#include "function.h"
#include "Assemblematrix.h"

#include <Eigen/Sparse>
#include <Eigen/Dense>
#include <armadillo>
#include <omp.h>

#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <tuple>
#include <cmath>
#include <numeric>

using namespace Eigen;
using namespace std;
using namespace arma;


SparseMatrixVectorResult DirichletBoundaryCondition(const string& meshFile, const int& tag) {

	//int num_th = 4;
	//omp_set_num_threads(num_th); // Nastavení počtu vláken

	SparseMatrixVectorResult resultS;
	MatrixVectorResult result1 = GetTriangles(meshFile);
	vector<int> vectorOfTags = result1.vector1;
	int nTri = result1.integerResult;		// poèet trojúhelníkùD
	int nNodes = result1.matrix3.size();			// poèet bodù
	int nNodes2 = 2 * nNodes*16;
	vector<int> I(nNodes2, 0);
	vector<int> J(nNodes2, 0);
	vector<double> VAL(nNodes2, 0);

	vector<double> bD = NeumannBoundaryCondition(meshFile, tag);


	vector<double> x(nNodes2, 0);
	double xx = 0;

	double cD = 1e9;
	// Vynásobení vektoru koeficientem
	for (double& element : bD) {
		element *= cD;
	}
	double Q1 = 0.5 - sqrt(3.0 / 5.0) / 2.0;
	//cout << "Q1D   " << Q1 << endl;
	double Q2 = 0.5;
	double Q3 = 0.5 + sqrt(3.0 / 5.0) / 2.0;


	vector<vector<vector<double>>> basisFE_ref = {
	{{fiD(Q1), 0}, {fiE(Q1),0}, {fiF(Q1),0}, {0,fiD(Q1)} , {0,fiE(Q1)}, {0,fiF(Q1) }},
	{{fiD(Q2), 0}, {fiE(Q2),0}, {fiF(Q2),0}, {0,fiD(Q2)} , {0,fiE(Q2)}, {0,fiF(Q2) }},
	{{fiD(Q3), 0}, {fiE(Q3),0}, {fiF(Q3),0}, {0,fiD(Q3)} , {0,fiE(Q3)}, {0,fiF(Q3) }}
	};

	vector<double> w = {5.0/18.0,4.0/9.0,5.0/18.0};
	double nQuadrature = 3;
	int index_IJ = 0;

	for (int k = 0; k < vectorOfTags.size(); k++) {

		if (vectorOfTags[k] == tag) {

			int D = result1.matrix2[k][0] - 1;					// Oznaèení vrcholù hran
			int E = result1.matrix2[k][1] - 1;
			int F = result1.matrix2[k][2] - 1;
			vector<int> edgeVertex = { D, E ,F };

			vector<double> cooD = result1.matrix3[D];		// Souøadnice vrcholù hran
			vector<double> cooE = result1.matrix3[E];

			//vector<vector<double>> matA = {
			//	{ cooE[0] - cooD[0] },
			//	{ cooE[1] - cooD[1] },
			//};
			double edgeLenght = sqrt((cooD[0] - cooE[0]) * (cooD[0] - cooE[0]) + (cooD[1] - cooE[1]) * (cooD[1] - cooE[1]));
			vector<int> index = { D, E,F, D + nNodes, E + nNodes, F + nNodes };

			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 6; j++) {
					double k_val = 0;
					for (int l = 0; l < nQuadrature; l++) {
						vector<double> v = basisFE_ref[l][j];
						//cout <<" i "<< i << " j " << j << " v " << v[0] <<" "<< v[1] << endl;
						//cout << "v  " << " i " << i << " j " << j << " l " << l << v[0] << "  " << v[1] << endl;
						vector<double> u = basisFE_ref[l][i];
						//cout << "	 u " << u[0] <<" "<< u[1] << endl;
						k_val = k_val + edgeLenght* w[l] * dotprod(u, v);
						//cout << "dotprod(u, v)		" << dotprod(u, v) << endl;

					};
					k_val = cD * k_val;
					I[index_IJ] = index[i];
					J[index_IJ] = index[j];
					VAL[index_IJ] = k_val;
					index_IJ++;
				};
			};
		};

	};
	SparseMatrixVectorResult assembledMatrix = AssembledMatrix(I, J, VAL, bD);



	return assembledMatrix;
}