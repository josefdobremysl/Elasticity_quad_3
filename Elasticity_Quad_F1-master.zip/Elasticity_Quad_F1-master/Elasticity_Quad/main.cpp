﻿#include "mesh_processor.h"
#include "Dirichlet.h"
#include "Neumann.h"
#include "Stiffnessmatrix.h"

#include <Eigen/Sparse>
#include <Eigen/Cholesky>
#include <Eigen/IterativeLinearSolvers>


#include <iostream>
#include <vector>
#include <tuple>
#include <Eigen/Sparse>
//#include "Case1.h"
//#include "Case2.h"
//#include "Case3.h"
//#include "Case4.h"
#include <chrono>	
#include "vtk.h"

using Time = std::chrono::steady_clock;
using ms = std::chrono::milliseconds;

int main() {

	const auto start = Time::now();

	std::string meshFile = "nosnik.txt";

	SparseMatrixVectorResult stiffness_matrix = StiffnessMatrix(meshFile);

	SparseMatrix<double> K = stiffness_matrix.sparsematrix;
	//// Převod na hustou matici
	//Eigen::MatrixXd KK = Eigen::MatrixXd(K);
	//vector<double> sumRowK(K.size(), 0);
	//for (int i = 0; i < KK.size(); i++) {
	//	for (int j = 0; j < KK.size(); j++) {
	//		sumRowK[i] = KK(i,j);

	//	};
	//};
	//for (int i = 0; i < sumRowK.size(); ++i) {
	//	std::cout << sumRowK[i] << " ";
	//}

	vector<double> right_side_vector0 = stiffness_matrix.right_side_vector;
	 
	//int tagN2 = 200;
	//vector<double> bN2 = NeumannBoundaryCondition(meshFile, tagN2);

	int tagN2 = 200;
	vector<double> bN2 = NeumannBoundaryCondition(meshFile, tagN2);

	//int tagD2 = 200;
	//SparseMatrixVectorResult Dirichlet2 = DirichletBoundaryCondition(meshFile, tagD2);

	int tagD5 = 500;
	SparseMatrixVectorResult Dirichlet5 = DirichletBoundaryCondition(meshFile, tagD5);
	SparseMatrix<double> sparsematrixDirichlet5 = Dirichlet5.sparsematrix;
	vector<double> bD5 = Dirichlet5.right_side_vector;


	// Velikost matice
	int numRows = bD5.size();
	int numCols = bD5.size();

	vector<double> right_side_vector(numRows, 0);
	//cout << right_side_vector0.size() << "/////" << bD5.size() << endl;
	for (int i = 0; i < bD5.size(); i++) {

		right_side_vector[i] = right_side_vector0[i] +bD5[i] +bN2[i];
		//cout <<  right_side_vector0[i]  << endl;
	}
	//cout << "K.rows()" << K.rows() << endl;
	//cout << "D.rows()" << sparsematrixDirichlet4.rows() << endl;
	SparseMatrix<double> A = K  + sparsematrixDirichlet5;

	//Eigen::VectorXd nul = K;


	// Pravá strana soustavy b
	Eigen::VectorXd b = Eigen::Map<Eigen::VectorXd>(right_side_vector.data(), right_side_vector.size());
	//cout << "b" << b << endl;

	//std::cout << "Eigen Sparse Matrix:" << std::endl;
	//std::cout << A << std::endl;

	//////////////////////  ŘEŠENÍ SOUSTAVY Konjugovane gradienty - Eigen\\\\\\\\\\\\\\\\\\\\\\\\\\

	const auto start1 = Time::now();

	//// Inicializace øešení
	Eigen::VectorXd x(numRows);

	ConjugateGradient<SparseMatrix<double>, Eigen::Upper> solver;
	x = solver.compute(A).solve(b);
	string meshFile2 = meshFile;

	//cout << "x" << x << endl;

	const auto end1 = Time::now();

	const auto diff1 = std::chrono::duration_cast<ms>(end1 - start1).count();

	std::cout << "Solution time Conjugate Gradient = " << diff1 << " ms" << "\n";

	const auto end = Time::now();
	const auto diff = std::chrono::duration_cast<ms>(end - start).count();
	std::cout << " Total time = " << diff << " ms" << "\n";
	 
	///////////////////////////////		VYPIS VTK		\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

	// Odvození jmena vystupniho souboru
	size_t dotPos = meshFile2.find_last_of(".");

	if (dotPos != std::string::npos && dotPos != meshFile2.size() - 1) {
		// Nahrazení části řetězce začínající po tečce novým řetězcem
		meshFile2 = meshFile2.substr(0, dotPos) + ".vtk";
	}
	else {
		meshFile2 += ".vtk";
	}
	VTKfile(meshFile2, meshFile, x);

	MatrixVectorResult result = GetTriangles(meshFile);


	//int nTri = result.integerResult;		// poèet trojúhelníkù
	//vector<int> I;
	//vector<int> J;
	//vector<double> VAL;
	int nNodes = result.matrix3.size();			// poèet bodù
	int nNodes2 = 2 * nNodes;
	vector<vector<double>>NodesM = result.matrix3;

	double Xi;
	double Yi;
	vector<double>UU(nNodes2, 0);

	//for (int i = 0; i < nNodes; i++) {
	//	Xi = NodesM[i][0];
	//	Yi = NodesM[i][1];
	//	UU[i] = Xi;
	//	UU[i + nNodes] = 0;
	//}

	//Eigen::VectorXd UUU = Eigen::Map<Eigen::VectorXd>(UU.data(), UU.size());
	//Eigen::VectorXd d = x - UUU;
	//string meshFilechyba = "ctverec_chyba.vtk";

	//VTKfile(meshFilechyba, meshFile, d);
}